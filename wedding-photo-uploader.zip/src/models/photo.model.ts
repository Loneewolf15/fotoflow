export interface Photo {
  imageUrl: string;
  note: string;
}
